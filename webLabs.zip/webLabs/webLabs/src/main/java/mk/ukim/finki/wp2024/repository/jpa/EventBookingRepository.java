package mk.ukim.finki.wp2024.repository.jpa;

import mk.ukim.finki.wp2024.model.EventBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventBookingRepository extends JpaRepository<EventBooking, Long> {
    List<EventBooking> searchEventBookingByEventName(String eventName);

}