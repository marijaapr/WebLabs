package mk.ukim.finki.wp2024.web.controller;

import jakarta.servlet.http.HttpSession;
import mk.ukim.finki.wp2024.model.Event;
import mk.ukim.finki.wp2024.model.Location;
import mk.ukim.finki.wp2024.service.EventService;
import mk.ukim.finki.wp2024.service.LocationService;
import mk.ukim.finki.wp2024.service.impl.EventServiceImpl;
import mk.ukim.finki.wp2024.service.impl.LocationServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import java.util.List;


@Controller
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;
    private final LocationService locationService;

    public EventController(EventServiceImpl eventService,
                           LocationServiceImpl locationService
                           ) {
        this.eventService = eventService;
        this.locationService = locationService;

    }

    @GetMapping
    public String getEventsPage(@RequestParam(required = false) String error,
                                @RequestParam(required = false) String search,
                                @RequestParam(required = false) Long searchByLocation,
                                Model model, HttpSession session) {
        if (error != null && !error.isEmpty()) {
            model.addAttribute("hasError", true);
            model.addAttribute("error", error);
        } else if (search != null && !search.isEmpty()) {
            model.addAttribute("events", eventService.searchEvents(search));
        }
        else if (searchByLocation != null) {
            model.addAttribute("events", eventService.findByLocation(searchByLocation));
        } else {
            model.addAttribute("events", eventService.listAll());
        }

        model.addAttribute("locations", locationService.findAll());
        return "listEvents";
    }

    @GetMapping("/add-form")
    public String getAddEventPage(Model model) {
        List<Location> locations = locationService.findAll();
        model.addAttribute("locations", locations);
        //model.addAttribute("categories", categories);
        return "add-event";
    }

    @PostMapping("/add")
    public String saveEvent(@RequestParam String name,
                            @RequestParam String description,

                            @RequestParam double popularityScore,
                            @RequestParam Long locationId,
                            @RequestParam int numTickets) {
        this.eventService.save(name, description, popularityScore, locationId, numTickets);
        return "redirect:/events";
    }

    @GetMapping("/edit-form/{id}")
    public String getEditEventForm(@PathVariable Long id, Model model) {
        if (eventService.findById(id).stream().findFirst().isPresent()) {
            Event event = eventService.findById(id).stream().findFirst().get();
            List<Location> locations = locationService.findAll();
            model.addAttribute("locations", locations);
            model.addAttribute("event", event);
            return "add-event";
        }
        return "redirect:/events?error=Event not found";
    }

    @PostMapping("/edit/{eventId}")
    public String editEvent(@PathVariable Long eventId,
                            @RequestParam String name,
                            @RequestParam String description,
                            @RequestParam double popularityScore,
                            @RequestParam Long locationId,
                            @RequestParam int numTickets) {
        if (eventId != null) {
            this.eventService.update(eventId, name, description, popularityScore, locationId, numTickets);
        } else {
            this.eventService.save(name, description, popularityScore, locationId, numTickets);
        }
        return "redirect:/events";
    }

    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id) {
        if (eventService.findById(id).isPresent()) {
            this.eventService.deleteById(id);
            return "redirect:/events";
        } else return "redirect:/events?error=Event not found";
    }

    @PostMapping("/search")
    public String getSearchedEvents(@RequestParam String search) {
        if (search != null && !search.isEmpty())
            return "redirect:/events?search=" + search;
        return "redirect:/events";
    }



    @PostMapping("/searchByLocation")
    public String getSearchedByLocationEvents(@RequestParam Long searchByLocation) {
        if (!eventService.findByLocation(searchByLocation).isEmpty()) {
            return "redirect:/events?searchByLocation=" + searchByLocation;
        }
        return "redirect:/events";
    }

    @GetMapping("/details/{id}")
    public String getDetails(@PathVariable Long id, Model model) {
        Event event = null;
        if (eventService.findById(id).isPresent())
            event = eventService.findById(id).get();
        model.addAttribute("event", event);
        return "details";
    }


}