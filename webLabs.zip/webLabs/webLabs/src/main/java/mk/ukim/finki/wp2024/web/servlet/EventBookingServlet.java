package mk.ukim.finki.wp2024.web.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.ukim.finki.wp2024.service.impl.EventServiceImpl;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;
import org.thymeleaf.web.IWebExchange;

import java.io.IOException;

@WebServlet(name = "EventBookingServlet", urlPatterns = {"/event-booking"})
public class EventBookingServlet extends HttpServlet {

    private final EventServiceImpl eventService;
    private final SpringTemplateEngine templateEngine;

    public EventBookingServlet(EventServiceImpl eventService, SpringTemplateEngine templateEngine) {
        this.eventService = eventService;
        this.templateEngine = templateEngine;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Prepare the context for Thymeleaf (without needing user object)
        IWebExchange exchange = JakartaServletWebApplication.buildApplication(req.getServletContext()).buildExchange(req, resp);
        WebContext context = new WebContext(exchange);

        // Show the initial booking confirmation page
        templateEngine.process("bookingConfirmation.html", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Retrieve the parameters from the request
        String eventName = req.getParameter("eventName");  // Event name selected
        String numOfTickets = req.getParameter("numTickets");  // Number of tickets requested

        // Retrieve the IP address of the user
        String clientIP = req.getRemoteAddr();
        String hostName = req.getRemoteHost();

        // Set these values in the Thymeleaf context for the confirmation page
        IWebExchange exchange = JakartaServletWebApplication.buildApplication(req.getServletContext()).buildExchange(req, resp);
        WebContext context = new WebContext(exchange);
        context.setVariable("hostName", hostName);
        context.setVariable("hostAddress", clientIP);
        context.setVariable("eventName", eventName);
        context.setVariable("numOfTickets", numOfTickets);

        // Process the confirmation page
        templateEngine.process("bookingConfirmation.html", context, resp.getWriter());
    }
}
