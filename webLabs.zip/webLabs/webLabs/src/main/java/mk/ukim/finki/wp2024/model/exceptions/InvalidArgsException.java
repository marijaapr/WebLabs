package mk.ukim.finki.wp2024.model.exceptions;

public class InvalidArgsException extends RuntimeException {
    public InvalidArgsException() {
        super("Invalid arguments exception");
    }
}
